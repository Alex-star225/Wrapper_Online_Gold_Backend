Two Hair

Adam Purposes and Others

In cc_theme.xml

Add:

<component type="hair" id="adam_light_hair" path="adam_light_hair" name="adam_light_hair" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>