Special Pants Pack

In cc_theme.xml

Add:

<component type="lower_body" id="adam_sbwithtor" path="adam_sbwithtor" name="adam_sbwithtor" thumb="thumbnail.swf" display_order="220" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="lower_body" id="adam_legrepeater" path="adam_legrepeater" name="adam_legrepeater" thumb="thumbnail.swf" display_order="220" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="lower_body" id="adam_legheavyjeans" path="adam_legheavyjeans" name="adam_legheavyjeans" thumb="thumbnail.swf" display_order="220" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="lower_body" id="adam_legfullsp" path="adam_legfullsp" name="adam_legfullsp" thumb="thumbnail.swf" display_order="220" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="lower_body" id="adam_bigreactorlegs" path="adam_bigreactorlegs" name="adam_bigreactorlegs" thumb="thumbnail.swf" display_order="220" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

Character type only