Don't put the characters into random folder otherwise your characters will also not work!

Please be aware, the characters that use Wrapper Gold Assets, or else it will be some glitches on characters if the basic assets are used, they will get something gritty and crazy!