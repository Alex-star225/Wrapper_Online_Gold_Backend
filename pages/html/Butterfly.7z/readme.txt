<component type="facedecoration" id="butterfly" path="butterfly" name="butterfly" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>

Put in the end.

PLEASE USE AS A EVE CHARACTER NOT ADAM, ROCKY OR BOB, EVE ARE BUTTERFLIES.