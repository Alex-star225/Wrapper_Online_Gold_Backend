Bloody FUll Eyes

Add:

<component type="eye" id="special_adamredeyes" path="special_adamredeyes" name="special_adamredeyes" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="asleep" filename="asleep.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="thinking" filename="thinking.swf"/>
        <state id="yawn" filename="yawn.swf"/>
    </component>