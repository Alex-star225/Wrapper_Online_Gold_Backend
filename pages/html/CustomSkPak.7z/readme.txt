Custom Skeleton Pack for Adam, Eve, Rocky.

Adam Actions:

<action id="tests1" name="Agree" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_surprised"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="agree"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests2" name="Bend dance" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="bend_dance"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests3" name="Bounce" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="bounce"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests4" name="Collapse" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="collapse"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="expacc1" name="Collapse" loop="Y" totalframe="30" category="evaporation" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="collapse"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="expacc2" name="Explode" loop="Y" totalframe="30" category="evaporation" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="explode"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="expacc3" name="Faint" loop="Y" totalframe="30" category="evaporation" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="faint"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="expacc4" name="Get beheaded" loop="Y" totalframe="30" category="evaporation" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="get_beheaded"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests5" name="Disagree" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="disagree"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests6" name="Double Kick" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="double_kick"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests7" name="Explode" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="explode"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests8" name="Faint" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_asleep"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="faint"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests9" name="Fearful 02" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_sad"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="fearful_02"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests10" name="Fearful Still" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_sad"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="fearful_still"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests11" name="Fight" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="fight"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests12" name="Get Beheaded" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_cry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="get_beheaded"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests13" name="Headbang" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="headbang"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests14" name="Hunch" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_evilsmile"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="hunch"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests15" name="IDK" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="idk"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests16" name="Little dance" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="little_dance"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests17" name="Punch 2" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="punch2"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests19" name="Shiver" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="shiver"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests20" name="Show me your" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="show_me_your"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests21" name="Silly dance" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="silly_dance"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests22" name="Sit on floor" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="sit_on_floor"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests23" name="Sprint" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_sick"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="sprint"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests24" name="Twerk" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="twerk"/>
            <selection type="upper_body" state_id="default"/>
        </action>

Eve Actions:

<action id="tests1" name="Bump" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="bump"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="fightxx1" name="Bump" loop="Y" totalframe="30" category="fighting" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="bump"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="fightxx2" name="Double kick" loop="Y" totalframe="30" category="fighting" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="double_kick"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="fightxx3" name="Headbutt" loop="Y" totalframe="30" category="fighting" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="headbutt"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="fightxx4" name="Kick" loop="Y" totalframe="30" category="fighting" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="kick"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="fightxx5" name="Kick 2" loop="Y" totalframe="30" category="fighting" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="excited"/>
            <selection type="skeleton" state_id="kick"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="veryexcitedx10" name="Very Excited" loop="Y" totalframe="30" category="emotion" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="excited"/>
            <selection type="skeleton" state_id="very_excited"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="tests2" name="Double kick" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="double_kick"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests4" name="Headbutt" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_sad"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="headbutt"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests5" name="Kick" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="kick"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests6" name="Look down cross" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="look_down_cross"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests8" name="Punch new" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_angry"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="punch"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests9" name="Sprint new" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_sick"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="sprint"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="tests10" name="Very excited" loop="Y" totalframe="30" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="very_excited"/>
            <selection type="upper_body" state_id="default"/>
        </action>

Rocky Actions:

<action id="tests1" name="Dance" loop="Y" totalframe="1" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="dance"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="danc1" name="Dance" loop="Y" totalframe="1" category="emotion" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_happy"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="dance"/>
            <selection type="upper_body" state_id="excited"/>
        </action>
		<action id="tests2" name="Sit Cross" loop="Y" totalframe="1" category="testing" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="sit_cross"/>
            <selection type="upper_body" state_id="default"/>
        </action>
		<action id="sitcr1" name="Sit Cross" loop="Y" totalframe="1" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="sit"/>
            <selection type="skeleton" state_id="sit_cross"/>
            <selection type="upper_body" state_id="sit"/>
        </action>
		<action id="sitcr2" name="Sit Cross 2" loop="Y" totalframe="1" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="kneel_down"/>
            <selection type="skeleton" state_id="sit_cross"/>
            <selection type="upper_body" state_id="sit"/>
        </action>
		<action id="sitcr3" name="Sit Cross 3" loop="Y" totalframe="1" enable="Y" is_motion="N">
            <selection type="facial" facial_id="head_neutral"/>
            <selection type="lower_body" state_id="default"/>
            <selection type="skeleton" state_id="sit_cross"/>
            <selection type="upper_body" state_id="sit"/>
        </action>

You will add the skeleton types otherwise it will not work.

Adam:

<component type="skeleton" id="adam_001" path="adam_001" name="adam_001" thumb="thumbnail.swf" display_order="0" money="0" sharing="0" enable="Y">
            <state id="bend" filename="bend.swf"/>
            <state id="benddown" filename="benddown.swf"/>
            <state id="bendup" filename="bendup.swf"/>
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="look_down" filename="look_down.swf"/>
            <state id="lookslightlydown" filename="lookslightlydown.swf"/>
            <state id="lookslightlyup" filename="lookslightlyup.swf"/>
            <state id="move" filename="move.swf"/>
			<state id="agree" filename="agree.swf"/>
			<state id="bend_dance" filename="bend_dance.swf"/>
			<state id="bounce" filename="bounce.swf"/>
			<state id="collapse" filename="collapse.swf"/>
			<state id="disagree" filename="disagree.swf"/>
			<state id="double_kick" filename="double_kick.swf"/>
			<state id="explode" filename="explode.swf"/>
			<state id="faint" filename="faint.swf"/>
			<state id="fearful_02" filename="fearful_02.swf"/>
			<state id="fearful_still" filename="fearful_still.swf"/>
			<state id="fight" filename="fight.swf"/>
			<state id="get_beheaded" filename="get_beheaded.swf"/>
			<state id="headbang" filename="headbang.swf"/>
			<state id="hunch" filename="hunch.swf"/>
			<state id="idk" filename="idk.swf"/>
			<state id="little_dance" filename="little_dance.swf"/>
			<state id="punch2" filename="punch2.swf"/>
			<state id="push" filename="push.swf"/>
			<state id="shiver" filename="shiver.swf"/>
			<state id="show_me_your" filename="show_me_your.swf"/>
			<state id="silly_dance" filename="silly_dance.swf"/>
			<state id="sit_on_floor" filename="sit_on_floor.swf"/>
			<state id="sprint" filename="sprint.swf"/>
			<state id="twerk" filename="twerk.swf"/>
            <!-- <state id="look_up" filename="look_up.swf"/> -->
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="stand" filename="stand.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="turnhead" filename="turnhead.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

Eve:

<component type="skeleton" id="eve_001" path="eve_001" name="eve_001" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
            <state id="benddown" filename="benddown.swf"/>
            <state id="bendup" filename="bendup.swf"/>
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lookslightlydown" filename="lookslightlydown.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="stand" filename="stand.swf"/>
            <state id="talk" filename="talk.swf"/>
			<state id="bump" filename="bump.swf"/>
			<state id="double_kick" filename="double_kick.swf"/>
			<state id="emo_stand" filename="emo_stand.swf"/>
			<state id="headbutt" filename="headbutt.swf"/>
			<state id="kick" filename="kick.swf"/>
			<state id="look_down_cross" filename="look_down_cross.swf"/>
			<state id="look_up" filename="look_up.swf"/>
			<state id="punch" filename="punch.swf"/>
			<state id="sprint" filename="sprint.swf"/>
			<state id="very_excited" filename="very_excited.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="talk_on_phone2" filename="talk_on_phone_2.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="turnhead" filename="turnhead.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

Rocky:

<component type="skeleton" id="rocky_001" path="rocky_001" name="rocky_001" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="laugh_point" filename="laugh_point.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="look_down" filename="look_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
			<state id="dance" filename="dance.swf"/>
			<state id="sit_cross" filename="sit_cross.swf"/>
			<state id="turn_head" filename="turn_head.swf"/>
			<state id="twitch" filename="twitch.swf"/>
            <state id="show_off" filename="show_off.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="stand" filename="stand.swf"/>
            <state id="talk_a" filename="talk_a.swf"/>
            <state id="talk_b" filename="talk_b.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

Other skeleton animations are invisible but if you did two times, the character creator will constantly freeze.