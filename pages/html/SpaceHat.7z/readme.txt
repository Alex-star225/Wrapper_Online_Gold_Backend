Space hat for Wrapper Online and Wrapper Offline

Add on cc_theme.xml and the end of component, make sure it's inside of component!

Add:

<component type="facedecoration" id="spacehat" path="spacehat" name="spacehat" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>

restart your server and see a new decoration on character creator