An Beta Ear by IUS.

Just open cc_theme.xml (FAMILY ONLY). Find the type of ear and you just copy on it and paste right here, then customize these values.

<component type="ear" id="beta_ear" path="beta_ear" name="beta_ear" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
</component>

Don't mess up or the new asset will not work!

Remember: The nothing state is just nothing in this asset, just replace thumbnail.swf when it has no nothing.swf on this pack.