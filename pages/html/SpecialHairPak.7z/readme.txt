Add a special hair in the inside of component in cc_theme.xml

Add:

<component type="hair" id="adam_gradienth" path="adam_gradienth" name="adam_gradienth" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="adam_light_hair" path="adam_light_hair" name="adam_light_hair" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="adam_prince" path="adam_prince" name="adam_prince" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="adam_saiyan" path="adam_saiyan" name="adam_saiyan" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="beautyhairnew1" path="beautyhairnew1" name="beautyhairnew1" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="flowerbluehair" path="flowerbluehair" name="flowerbluehair" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="yellowpoyohair" path="yellowpoyohair" name="yellowpoyohair" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="jessiehair" path="jessiehair" name="jessiehair" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="lilywithpin" path="lilywithpin" name="lilywithpin" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="orangebrcrh" path="orangebrcrh" name="orangebrcrh" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="poyohair" path="poyohair" name="poyohair" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>
	<component type="hair" id="stephanienew" path="stephanienew" name="stephanienew" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="thumbnail.swf"/>
    </component>