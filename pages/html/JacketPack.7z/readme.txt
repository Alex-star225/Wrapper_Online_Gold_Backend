An Jacket Pack for Adam Characters

Put the jackets on cc_theme.xml:

<component type="upper_body" id="adam_jacketpockets" path="adam_jacketpockets" name="adam_jacketpockets" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_sideshirt" path="adam_sideshirt" name="adam_sideshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_sideshirt2" path="adam_sideshirt2" name="adam_sideshirt2" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_gloveshirts" path="adam_gloveshirts" name="adam_gloveshirts" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_shirtbuttons" path="adam_shirtbuttons" name="adam_shirtbuttons" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_cooljacket" path="adam_cooljacket" name="adam_cooljacket" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_sideonlyshirt" path="adam_sideonlyshirt" name="adam_sideonlyshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_jacketside" path="adam_jacketside" name="adam_jacketside" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_shirtribbons" path="adam_shirtribbons" name="adam_shirtribbons" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_nojacketside" path="adam_nojacketside" name="adam_nojacketside" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_glovewool" path="adam_glovewool" name="adam_glovewool" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_sportshirtside" path="adam_sportshirtside" name="adam_sportshirtside" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_nodiamondshirt" path="adam_nodiamondshirt" name="adam_nodiamondshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_classicshirt" path="adam_classicshirt" name="adam_classicshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_bagpack" path="adam_bagpack" name="adam_bagpack" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_shirtfub" path="adam_shirtfub" name="adam_shirtfub" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_semigloveshirt" path="adam_semigloveshirt" name="adam_semigloveshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_heavyjacket" path="adam_heavyjacket" name="adam_heavyjacket" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_thinsportshirt" path="adam_thinsportshirt" name="adam_thinsportshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_longsportshirt" path="adam_longsportshirt" name="adam_longsportshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_inlineshirt" path="adam_inlineshirt" name="adam_inlineshirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_dressershirt" path="adam_dressershirt" name="adam_dressershirt" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_jacketbars" path="adam_jacketbars" name="adam_jacketbars" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_officebuttons" path="adam_officebuttons" name="adam_officebuttons" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_jacketshape" path="adam_jacketshape" name="adam_jacketshape" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_jacketcape" path="adam_jacketcape" name="adam_jacketcape" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>
		<component type="upper_body" id="adam_thinshirtside" path="adam_thinshirtside" name="adam_thinshirtside" thumb="thumbnail.swf" display_order="180" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

please be choose an adam character inside, not other character type or it will not appear, it will appear the wrong type of jackets