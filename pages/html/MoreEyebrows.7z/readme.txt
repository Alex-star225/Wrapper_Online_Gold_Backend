add on eyebrows in cc_theme.xml end of character type or go deeper in the end

add:

<component type="eyebrow" id="adam_angrybirdseb" path="adam_angrybirdseb" name="adam_angrybirdseb" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="nothing.swf"/>
        <state id="disgusted" filename="disgusted.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="surprised" filename="surprised.swf"/>
        <state id="talk" filename="talk.swf"/>
        <state id="yawn" filename="yawn.swf"/>
    </component>
	<component type="eyebrow" id="adam_bosseb" path="adam_bosseb" name="adam_bosseb" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="nothing.swf"/>
        <state id="disgusted" filename="disgusted.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="surprised" filename="surprised.swf"/>
        <state id="talk" filename="talk.swf"/>
        <state id="yawn" filename="yawn.swf"/>
    </component>
	<component type="eyebrow" id="adam_longbrowneb" path="adam_longbrowneb" name="adam_longbrowneb" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="nothing.swf"/>
        <state id="disgusted" filename="disgusted.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="surprised" filename="surprised.swf"/>
        <state id="talk" filename="talk.swf"/>
        <state id="yawn" filename="yawn.swf"/>
    </component>
	<component type="eyebrow" id="adam_pringlesbrowneb" path="adam_pringlesbrowneb" name="adam_pringlesbrowneb" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="nothing" filename="nothing.swf"/>
        <state id="disgusted" filename="disgusted.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="surprised" filename="surprised.swf"/>
        <state id="talk" filename="talk.swf"/>
        <state id="yawn" filename="yawn.swf"/>
    </component>

make sure to move the eyebrows because they are slided down